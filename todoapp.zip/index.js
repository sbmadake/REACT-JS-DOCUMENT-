import 'babel-polyfill'
import React from 'react'
import { render } from 'react-dom'
import { Provider } from 'react-redux'
import { createStore, applyMiddleware } from 'redux'
import todoApp from './reducers'
import App from './components/App'
import helloSaga from './sagas/sagas'
import createSagaMiddleware from 'redux-saga'

const sagaMiddleware = createSagaMiddleware()

let store = createStore(todoApp, applyMiddleware(sagaMiddleware))
sagaMiddleware.run(helloSaga);

render( < Provider store = { store } >
    <
    App / >
    <
    /Provider>,document.getElementById('root')
)