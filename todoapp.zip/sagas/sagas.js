function* helloSaga() {
    console.log('Hello Sagas!')
}

export default helloSaga;